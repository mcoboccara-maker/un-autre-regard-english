/// DÉTECTEUR DE LANGUE LOCAL
/// 
/// Fichier : lib/services/language_detector.dart
/// Usage  : Détecter la langue d'un texte utilisateur (français, anglais, hébreu)
/// 
/// Utilise des heuristiques locales (pas d'API externe) :
/// - Détection Unicode pour l'hébreu
/// - Mots-clés et patterns pour français/anglais

class LanguageDetector {
  
  // Codes de langue supportés
  static const String french = 'fr';
  static const String english = 'en';
  static const String hebrew = 'he';
  
  // Langue par défaut
  static const String defaultLanguage = french;
  
  /// Détecte la langue du texte donné
  /// Retourne le code de langue (fr, en, he)
  static String detect(String text) {
    if (text.isEmpty) return defaultLanguage;
    
    final trimmedText = text.trim();
    if (trimmedText.isEmpty) return defaultLanguage;
    
    // 1. Détection de l'hébreu par Unicode (U+0590 - U+05FF)
    if (_containsHebrew(trimmedText)) {
      return hebrew;
    }
    
    // 2. Détection français vs anglais par heuristiques
    return _detectFrenchOrEnglish(trimmedText);
  }
  
  /// Vérifie si le texte contient des caractères hébreux
  static bool _containsHebrew(String text) {
    // Range Unicode hébreu : U+0590 à U+05FF
    final hebrewPattern = RegExp(r'[\u0590-\u05FF]');
    return hebrewPattern.hasMatch(text);
  }
  
  /// Détecte si le texte est en français ou en anglais
  static String _detectFrenchOrEnglish(String text) {
    final lowerText = text.toLowerCase();
    
    int frenchScore = 0;
    int englishScore = 0;
    
    // ══════════════════════════════════════════════════════════════════════
    // PRONOMS PERSONNELS (fort indicateur)
    // ══════════════════════════════════════════════════════════════════════
    
    // Français
    if (RegExp(r'\bje\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\btu\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bnous\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bvous\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bils?\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\belles?\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bon\b').hasMatch(lowerText)) frenchScore += 2;
    
    // Anglais
    if (RegExp(r'\bi\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\byou\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bwe\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bthey\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bhe\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bshe\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bit\b').hasMatch(lowerText)) englishScore += 2;
    
    // ══════════════════════════════════════════════════════════════════════
    // ARTICLES (indicateur moyen)
    // ══════════════════════════════════════════════════════════════════════
    
    // Français
    if (RegExp(r'\ble\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bla\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bles\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bun\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bune\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bdes\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bdu\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bau\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\baux\b').hasMatch(lowerText)) frenchScore += 2;
    
    // Anglais
    if (RegExp(r'\bthe\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\ba\b').hasMatch(lowerText)) englishScore += 1;
    if (RegExp(r'\ban\b').hasMatch(lowerText)) englishScore += 2;
    
    // ══════════════════════════════════════════════════════════════════════
    // MOTS FRÉQUENTS (indicateur fort)
    // ══════════════════════════════════════════════════════════════════════
    
    // Français - verbes et mots courants
    if (RegExp(r'\best\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bsuis\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bsont\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bavec\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bpour\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bdans\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bque\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bqui\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bquoi\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bcomment\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bpourquoi\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bquand\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bplus\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bmoins\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\btrès\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\btrop\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bpas\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bne\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bmais\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bou\b').hasMatch(lowerText)) frenchScore += 1;
    if (RegExp(r'\bet\b').hasMatch(lowerText)) frenchScore += 1;
    if (RegExp(r'\bmon\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bma\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bmes\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bton\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bta\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\btes\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bson\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bsa\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bses\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bce\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bcette\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bces\b').hasMatch(lowerText)) frenchScore += 2;
    if (RegExp(r'\bparce\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\baussi\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bdonc\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bvoici\b').hasMatch(lowerText)) frenchScore += 3;
    if (RegExp(r'\bvoilà\b').hasMatch(lowerText)) frenchScore += 3;
    
    // Anglais - verbes et mots courants
    if (RegExp(r'\bis\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bam\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bare\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bwas\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bwere\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bhave\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bhas\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bhad\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bwith\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bfor\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bin\b').hasMatch(lowerText)) englishScore += 1;
    if (RegExp(r'\bthat\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bwhat\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bwho\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bhow\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bwhy\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bwhen\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bwhere\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bmore\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bless\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bvery\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\btoo\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bnot\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bbut\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bor\b').hasMatch(lowerText)) englishScore += 1;
    if (RegExp(r'\band\b').hasMatch(lowerText)) englishScore += 1;
    if (RegExp(r'\bmy\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\byour\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bhis\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bher\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bits\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bour\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\btheir\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bthis\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bthat\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bthese\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bthose\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bbecause\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\balso\b').hasMatch(lowerText)) englishScore += 3;
    if (RegExp(r'\bso\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bhere\b').hasMatch(lowerText)) englishScore += 2;
    if (RegExp(r'\bthere\b').hasMatch(lowerText)) englishScore += 2;
    
    // ══════════════════════════════════════════════════════════════════════
    // CARACTÈRES ACCENTUÉS FRANÇAIS (indicateur fort)
    // ══════════════════════════════════════════════════════════════════════
    
    if (RegExp(r'[éèêëàâäùûüôöîïç]').hasMatch(lowerText)) {
      frenchScore += 5;
    }
    
    // ══════════════════════════════════════════════════════════════════════
    // CONTRACTIONS SPÉCIFIQUES
    // ══════════════════════════════════════════════════════════════════════
    
    // Français - contractions avec apostrophe
    if (lowerText.contains("c'est")) frenchScore += 4;
    if (lowerText.contains("j'ai")) frenchScore += 4;
    if (lowerText.contains("j'")) frenchScore += 3;
    if (lowerText.contains("l'")) frenchScore += 2;
    if (lowerText.contains("d'")) frenchScore += 2;
    if (lowerText.contains("n'")) frenchScore += 2;
    if (lowerText.contains("qu'")) frenchScore += 3;
    if (lowerText.contains("s'")) frenchScore += 2;
    if (lowerText.contains("m'")) frenchScore += 2;
    if (lowerText.contains("t'")) frenchScore += 2;
    
    // Anglais - contractions
    if (lowerText.contains("i'm")) englishScore += 4;
    if (lowerText.contains("i've")) englishScore += 4;
    if (lowerText.contains("i'll")) englishScore += 4;
    if (lowerText.contains("i'd")) englishScore += 4;
    if (lowerText.contains("don't")) englishScore += 4;
    if (lowerText.contains("doesn't")) englishScore += 4;
    if (lowerText.contains("didn't")) englishScore += 4;
    if (lowerText.contains("can't")) englishScore += 4;
    if (lowerText.contains("won't")) englishScore += 4;
    if (lowerText.contains("wouldn't")) englishScore += 4;
    if (lowerText.contains("couldn't")) englishScore += 4;
    if (lowerText.contains("shouldn't")) englishScore += 4;
    if (lowerText.contains("isn't")) englishScore += 4;
    if (lowerText.contains("aren't")) englishScore += 4;
    if (lowerText.contains("wasn't")) englishScore += 4;
    if (lowerText.contains("weren't")) englishScore += 4;
    if (lowerText.contains("haven't")) englishScore += 4;
    if (lowerText.contains("hasn't")) englishScore += 4;
    if (lowerText.contains("hadn't")) englishScore += 4;
    if (lowerText.contains("it's")) englishScore += 3;
    if (lowerText.contains("that's")) englishScore += 3;
    if (lowerText.contains("what's")) englishScore += 3;
    if (lowerText.contains("there's")) englishScore += 3;
    if (lowerText.contains("here's")) englishScore += 3;
    if (lowerText.contains("let's")) englishScore += 3;
    
    // ══════════════════════════════════════════════════════════════════════
    // DÉCISION FINALE
    // ══════════════════════════════════════════════════════════════════════
    
    if (frenchScore > englishScore) return french;
    if (englishScore > frenchScore) return english;
    
    // En cas d'égalité, retourner le français par défaut
    return defaultLanguage;
  }
  
  /// Retourne le nom de la langue pour affichage
  static String getLanguageName(String code) {
    switch (code) {
      case french: return 'Français';
      case english: return 'English';
      case hebrew: return 'עברית';
      default: return 'Unknown';
    }
  }
  
  /// Vérifie si une langue est supportée
  static bool isSupported(String code) {
    return code == french || code == english || code == hebrew;
  }
}
