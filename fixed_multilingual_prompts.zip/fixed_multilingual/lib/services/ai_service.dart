import 'dart:convert';
import 'dart:math';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import '../models/reflection.dart';
import '../models/emotional_state.dart';
import '../models/user_profile.dart';
import '../services/persistent_storage_service.dart';
import '../services/character_tracking_service.dart';
import '../services/language_detector.dart';
import '../config/approach_config.dart';
// ═══════════════════════════════════════════════════════════════════════════════
// IMPORTS PROMPTS MULTILINGUES
// ═══════════════════════════════════════════════════════════════════════════════
import '../config/prompts/prompt_selector.dart';
// Imports directs pour les cas sans texte utilisateur (fallback français)
import '../config/prompts/fr/prompt_system_unifie.dart';
import '../config/prompts/fr/prompt_synthese.dart';

/// SERVICE IA - VERSION CLAUDE (ANTHROPIC) MULTILINGUE
class AIService {
  static AIService? _instance;
  static AIService get instance => _instance ??= AIService._();
  AIService._();

  // ═══════════════════════════════════════════════════════════════════════════
  // CONFIGURATION API CLAUDE (ANTHROPIC)
  // ═══════════════════════════════════════════════════════════════════════════
  
  final String _baseUrl = 'https://api.anthropic.com/v1/messages';
  String _apiKey = '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';
  
  final String _model = 'claude-sonnet-4-5-20250929';
  final String _modelFast = 'claude-3-5-haiku-20241022';
  
  final String _anthropicVersion = '2023-06-01';
  
  static const int _requestTimeoutSeconds = 60;
  static const int _maxRetryAttempts = 3;
  static const int _initialRetryDelaySeconds = 2;

  // ═══════════════════════════════════════════════════════════════════════════
  // SOURCES NÉCESSITANT LE MODÈLE DE QUALITÉ (SONNET)
  // ═══════════════════════════════════════════════════════════════════════════
  
  static const List<String> _spiritualSources = [
    'judaisme', 'christianisme', 'islam', 'bouddhisme', 'hindouisme',
    'soufisme', 'zen', 'taoisme',
    'kabbale', 'hassidisme', 'moussar', 'rabbinique',
    'mystique', 'contemplatif',
  ];

  bool _requiresQualityModel(String sourceKey) {
    return _spiritualSources.any((s) => sourceKey.toLowerCase().contains(s));
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SOURCES PAR DEFAUT
  // ═══════════════════════════════════════════════════════════════════════════
  static const List<String> _defaultSources = [
    'roman_psychologique',
    'schemas_young',
    'existentialisme_philo',
    'hannah_arendt',
  ];

  List<String> get userApproches => _userApproaches;
  List<String> _userApproaches = [];

  Map<String, int> _sourceUsageHistory = {};

  // ═══════════════════════════════════════════════════════════════════════════
  // CHARGEMENT DES APPROCHES UTILISATEUR
  // ═══════════════════════════════════════════════════════════════════════════

  Future<void> loadUserApproaches() async {
    try {
      final approaches = await PersistentStorageService.instance.getUserApproaches();
      
      if (approaches.isEmpty) {
        _userApproaches = List.from(_defaultSources);
        print('AIService: Aucune source utilisateur -> Sources par défaut: $_userApproaches');
      } else {
        _userApproaches = approaches;
        print('AIService: Sources utilisateur chargées: $_userApproaches');
      }
    } catch (e) {
      print('AIService: Erreur chargement approches: $e');
      _userApproaches = List.from(_defaultSources);
    }
  }

  Map<String, List<String>> _categorizeApproaches(List<String> approaches) {
    final categories = <String, List<String>>{
      'religions': <String>[],
      'litteratures': <String>[],
      'psychologies': <String>[],
      'philosophies': <String>[],
      'philosophes': <String>[],
    };
    
    for (final approach in approaches) {
      try {
        final config = ApproachCategories.allApproaches.firstWhere(
          (a) => a.key == approach,
          orElse: () => ApproachConfig(
            key: approach,
            name: approach,
            description: '',
            credo: '',
            tonEmotionnel: '',
            exemples: [],
            icon: Icons.help,
            color: Colors.grey,
            type: ApproachType.psychological,
          ),
        );
        
        switch (config.type) {
          case ApproachType.spiritual:
            categories['religions']!.add(config.name);
            break;
          case ApproachType.literary:
            categories['litteratures']!.add(config.name);
            break;
          case ApproachType.psychological:
            categories['psychologies']!.add(config.name);
            break;
          case ApproachType.philosophical:
            categories['philosophies']!.add(config.name);
            break;
          case ApproachType.philosopher:
            categories['philosophes']!.add(config.name);
            break;
        }
      } catch (e) {
        print('AIService: Erreur catégorisation $approach: $e');
      }
    }
    
    return categories;
  }

  String _calculateAge(UserProfile? userProfile) {
    if (userProfile?.dateNaissance == null) {
      return 'Non renseigné';
    }
    final now = DateTime.now();
    final birthDate = userProfile!.dateNaissance!;
    int age = now.year - birthDate.year;
    if (now.month < birthDate.month || 
        (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }
    return age.toString();
  }

  String _getTypeDisplayName(ReflectionType type) {
    switch (type) {
      case ReflectionType.thought:
        return 'Pensée';
      case ReflectionType.situation:
        return 'Situation';
      case ReflectionType.dilemma:
        return 'Dilemme';
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GESTION DES ERREURS API CLAUDE
  // ═══════════════════════════════════════════════════════════════════════════

  String _getErrorMessage(int statusCode, String responseBody) {
    String? apiMessage;
    try {
      final json = jsonDecode(responseBody);
      apiMessage = json['error']?['message'];
    } catch (_) {}
    
    switch (statusCode) {
      case 400:
        return 'Requête invalide. ${apiMessage ?? "Vérifiez les paramètres."}';
      case 401:
        return 'Clé API invalide ou expirée.';
      case 403:
        return 'Accès refusé. ${apiMessage ?? ""}';
      case 404:
        return 'Service non trouvé.';
      case 429:
        return 'Limite de requêtes atteinte. Veuillez patienter.';
      case 500:
        return 'Erreur serveur Claude.';
      case 529:
        return 'API Claude surchargée. Veuillez réessayer.';
      default:
        return 'Erreur inattendue ($statusCode). ${apiMessage ?? ""}';
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // APPEL API CLAUDE
  // ═══════════════════════════════════════════════════════════════════════════
  
  Future<String> _callClaude(
    String userPrompt, {
    String? systemPrompt,
    int maxTokens = 800,
    double temperature = 0.7,
    bool useQualityModel = false,
  }) async {
    final effectiveSystemPrompt = systemPrompt ?? PromptSystemUnifie.content;
    final effectiveModel = useQualityModel ? _model : _modelFast;
    
    for (int attempt = 1; attempt <= _maxRetryAttempts; attempt++) {
      try {
        print('AIService: Envoi requête Claude (tentative $attempt/$_maxRetryAttempts)...');
        print('AIService: Model: $effectiveModel');
        
        final response = await http.post(
          Uri.parse(_baseUrl),
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': _apiKey,
            'anthropic-version': _anthropicVersion,
          },
          body: jsonEncode({
            'model': effectiveModel,
            'max_tokens': maxTokens,
            'system': effectiveSystemPrompt,
            'messages': [
              {
                'role': 'user',
                'content': userPrompt,
              }
            ],
            'temperature': temperature,
          }),
        ).timeout(
          Duration(seconds: _requestTimeoutSeconds),
          onTimeout: () {
            throw TimeoutException('Timeout');
          },
        );

        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          final content = data['content']?[0]?['text'] ?? '';
          print('AIService: ✅ Réponse reçue: ${content.length} caractères');
          return content.trim();
        }
        
        if (response.statusCode == 429 || response.statusCode == 529) {
          if (attempt < _maxRetryAttempts) {
            final delaySeconds = _initialRetryDelaySeconds * (1 << (attempt - 1));
            print('AIService: ⏳ Erreur ${response.statusCode} - Retry dans ${delaySeconds}s');
            await Future.delayed(Duration(seconds: delaySeconds));
            continue;
          }
          final errorMsg = _getErrorMessage(response.statusCode, response.body);
          return '[ERREUR_API] $errorMsg';
        }
        
        final errorMsg = _getErrorMessage(response.statusCode, response.body);
        print('AIService: ❌ Erreur API: ${response.statusCode}');
        return '[ERREUR_API] $errorMsg';
        
      } on TimeoutException {
        if (attempt < _maxRetryAttempts) {
          await Future.delayed(Duration(seconds: _initialRetryDelaySeconds * (1 << (attempt - 1))));
          continue;
        }
        return '[ERREUR_API] Délai dépassé.';
      } catch (e) {
        print('AIService: ❌ Erreur: $e');
        if (attempt < _maxRetryAttempts) {
          await Future.delayed(Duration(seconds: _initialRetryDelaySeconds * (1 << (attempt - 1))));
          continue;
        }
        return '[ERREUR_API] Erreur réseau.';
      }
    }
    
    return '[ERREUR_API] Échec après plusieurs tentatives.';
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EXTRACTION DES MÉTADONNÉES DE FIGURE
  // ═══════════════════════════════════════════════════════════════════════════

  Map<String, String>? _extractFigureMeta(String response) {
    final regex = RegExp(
      r'\[FIGURE_META\]\s*\n'
      r'nom:\s*(.+)\n'
      r'source:\s*(.+)\n'
      r'reference:\s*(.+)\n'
      r'motif:\s*(.+)\n'
      r'\[/FIGURE_META\]',
      multiLine: true,
    );
    
    final match = regex.firstMatch(response);
    if (match == null) return null;
    
    return {
      'nom': match.group(1)?.trim() ?? '',
      'source': match.group(2)?.trim() ?? '',
      'reference': match.group(3)?.trim() ?? '',
      'motifUniversel': match.group(4)?.trim() ?? '',
    };
  }

  String _removeMetaBlock(String response) {
    return response.replaceAll(
      RegExp(r'\[FIGURE_META\][\s\S]*?\[/FIGURE_META\]'),
      '',
    ).trim();
  }

  Future<void> _saveExtractedCharacter(Map<String, String>? characterData) async {
    if (characterData == null || characterData['nom']?.isEmpty == true) return;
    try {
      await CharacterTrackingService.instance.saveMultipleCharacters([characterData]);
    } catch (e) {
      print('AIService: Erreur sauvegarde personnage: $e');
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GÉNÉRATION UNIVERSELLE (MULTILINGUE)
  // ═══════════════════════════════════════════════════════════════════════════
  
  Future<String> generateUniversalResponse({
    required String reflectionText,
    required ReflectionType reflectionType,
    required EmotionalState emotionalState,
    UserProfile? userProfile,
    String? declencheur,
    String? souhait,
    String? petitPas,
    int intensiteEmotionnelle = 5,
    String? historique30Jours,
  }) async {
    
    await loadUserApproaches();
    
    final personnagesInterdits = await CharacterTrackingService.instance.getForbiddenCharactersText();
    final categories = _categorizeApproaches(_userApproaches);
    String ageStr = _calculateAge(userProfile);
    
    // Réinitialiser le cache de langue
    PromptSelector.resetCache();
    
    // Construire le prompt multilingue
    final prompt = PromptSelector.buildUnifiedPrompt(
      userText: reflectionText,
      userPrenom: userProfile?.prenom,
      userAge: ageStr,
      userValeursSelectionnees: userProfile?.valeursSelectionnees?.join(', '),
      userValeursLibres: userProfile?.valeursLibres,
      typeEntree: _getTypeDisplayName(reflectionType),
      contenu: reflectionText,
      religions: categories['religions']!.isNotEmpty 
          ? categories['religions']!.join(', ') 
          : 'Aucune selectionnee',
      litteratures: categories['litteratures']!.isNotEmpty 
          ? categories['litteratures']!.join(', ') 
          : 'Aucun selectionne',
      psychologies: categories['psychologies']!.isNotEmpty 
          ? categories['psychologies']!.join(', ') 
          : 'Aucune selectionnee',
      philosophies: categories['philosophies']!.isNotEmpty 
          ? categories['philosophies']!.join(', ') 
          : 'Aucun selectionne',
      philosophes: categories['philosophes']!.isNotEmpty 
          ? categories['philosophes']!.join(', ') 
          : 'Aucun selectionne',
      historique30Jours: historique30Jours,
      personnagesInterdits: personnagesInterdits,
    );
    
    final systemPrompt = PromptSelector.getSystemPrompt(reflectionText);
    print('AIService: Langue détectée: ${PromptSelector.currentLanguageName}');

    try {
      final response = await _callClaude(
        prompt,
        systemPrompt: systemPrompt,
        maxTokens: 800,
        useQualityModel: true,
      );
      
      if (response.startsWith('[ERREUR_API]')) {
        return '❌ ${response.replaceFirst('[ERREUR_API] ', '')}';
      }
      
      if (response.isEmpty) {
        return '❌ Erreur lors de la génération de la réponse.';
      }
      
      final figureMeta = _extractFigureMeta(response);
      await _saveExtractedCharacter(figureMeta);
      
      return _removeMetaBlock(response);
      
    } catch (e) {
      print('AIService: Erreur génération universelle: $e');
      return '❌ Erreur lors de la génération de la réponse.';
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GÉNÉRATION POUR APPROCHE SPÉCIFIQUE (ROUE DU HASARD)
  // ═══════════════════════════════════════════════════════════════════════════
  
  Future<String> generateApproachSpecificResponse({
    required String approach,
    required String reflectionText,
    required ReflectionType reflectionType,
    required EmotionalState emotionalState,
    UserProfile? userProfile,
    String? declencheur,
    String? souhait,
    String? petitPas,
    required int intensiteEmotionnelle,
    String? historique30Jours,
  }) async {
    
    final approachConfig = ApproachCategories.allApproaches.firstWhere(
      (a) => a.key == approach,
      orElse: () => ApproachConfig(
        key: approach,
        name: approach,
        description: '',
        credo: '',
        tonEmotionnel: '',
        exemples: [],
        icon: Icons.psychology,
        color: Colors.blue,
        type: ApproachType.psychological,
      ),
    );

    final personnagesInterdits = await CharacterTrackingService.instance.getForbiddenCharactersText();
    String ageStr = _calculateAge(userProfile);
    
    PromptSelector.resetCache();
    
    String religionsStr = 'Aucune';
    String litteraturesStr = 'Aucun';
    String psychologiesStr = 'Aucune';
    String philosophiesStr = 'Aucun';
    String philosophesStr = 'Aucun';
    
    switch (approachConfig.type) {
      case ApproachType.spiritual:
        religionsStr = approachConfig.name;
        break;
      case ApproachType.literary:
        litteraturesStr = approachConfig.name;
        break;
      case ApproachType.psychological:
        psychologiesStr = approachConfig.name;
        break;
      case ApproachType.philosophical:
        philosophiesStr = approachConfig.name;
        break;
      case ApproachType.philosopher:
        philosophesStr = approachConfig.name;
        break;
    }
    
    final prompt = PromptSelector.buildUnifiedPrompt(
      userText: reflectionText,
      userPrenom: userProfile?.prenom,
      userAge: ageStr,
      userValeursSelectionnees: userProfile?.valeursSelectionnees?.join(', '),
      userValeursLibres: userProfile?.valeursLibres,
      typeEntree: _getTypeDisplayName(reflectionType),
      contenu: reflectionText,
      religions: religionsStr,
      litteratures: litteraturesStr,
      psychologies: psychologiesStr,
      philosophies: philosophiesStr,
      philosophes: philosophesStr,
      historique30Jours: historique30Jours,
      personnagesInterdits: personnagesInterdits,
    );
    
    final systemPrompt = PromptSelector.getSystemPrompt(reflectionText);

    try {
      final useQuality = _requiresQualityModel(approach);
      
      final response = await _callClaude(
        prompt,
        systemPrompt: systemPrompt,
        maxTokens: 800,
        useQualityModel: useQuality,
      );
      
      if (response.startsWith('[ERREUR_API]')) {
        return '❌ ${response.replaceFirst('[ERREUR_API] ', '')}';
      }
      
      if (response.isEmpty) {
        return '❌ Erreur lors de la génération de la réponse.';
      }
      
      final figureMeta = _extractFigureMeta(response);
      await _saveExtractedCharacter(figureMeta);
      
      return _removeMetaBlock(response);
      
    } catch (e) {
      return '❌ Erreur lors de la génération de la réponse.';
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GÉNÉRATION APPROFONDISSEMENT (MULTILINGUE)
  // ═══════════════════════════════════════════════════════════════════════════

  Future<String> generateDeepening({
    required String penseeOriginale,
    required String reponseCourte,
    required String sourceNom,
    required String figureNom,
  }) async {
    print('AIService: Approfondissement pour $sourceNom');
    
    PromptSelector.resetCache();
    
    final prompt = PromptSelector.buildDeepeningPrompt(
      userText: penseeOriginale,
      penseeOriginale: penseeOriginale,
      reponseCourte: reponseCourte,
      sourceNom: sourceNom,
      figureNom: figureNom,
    );
    
    final systemPrompt = PromptSelector.getSystemPrompt(penseeOriginale);
    
    try {
      final response = await _callClaude(
        prompt,
        systemPrompt: systemPrompt,
        maxTokens: 1500,
        useQualityModel: true,
      );
      
      if (response.startsWith('[ERREUR_API]')) {
        throw Exception(response.replaceFirst('[ERREUR_API] ', ''));
      }
      
      if (response.isEmpty) {
        throw Exception('Réponse vide');
      }
      
      return response;
      
    } catch (e) {
      print('AIService: ❌ Erreur approfondissement: $e');
      rethrow;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GÉNÉRATION PENSÉE POSITIVE (MULTILINGUE)
  // ═══════════════════════════════════════════════════════════════════════════
  
  Future<String> generatePositiveThought({
    UserProfile? userProfile,
    String? penseeOuSituation,
    String? historique7Jours,
  }) async {
    
    List<String> allSources = await PersistentStorageService.instance.getUserApproaches();
    
    if (allSources.isEmpty) {
      allSources = List.from(_defaultSources);
    }
    
    final selectedSource = _selectWeightedSource(allSources);
    _sourceUsageHistory[selectedSource] = (_sourceUsageHistory[selectedSource] ?? 0) + 1;
    
    final sourceConfig = ApproachCategories.allApproaches.firstWhere(
      (a) => a.key == selectedSource,
      orElse: () => ApproachConfig(
        key: selectedSource,
        name: selectedSource,
        description: '',
        credo: '',
        tonEmotionnel: '',
        exemples: [],
        icon: Icons.help,
        color: Colors.grey,
        type: ApproachType.psychological,
      ),
    );
    
    final categories = _categorizeApproaches(allSources);
    String ageStr = _calculateAge(userProfile);
    
    final langReference = historique7Jours ?? penseeOuSituation ?? 'fr';
    
    PromptSelector.resetCache();
    
    final prompt = PromptSelector.buildPositiveThoughtPrompt(
      userText: langReference,
      userPrenom: userProfile?.prenom,
      userAge: ageStr,
      userValeursSelectionnees: userProfile?.valeursSelectionnees?.join(', '),
      userValeursLibres: userProfile?.valeursLibres,
      religions: categories['religions']!.isNotEmpty 
          ? categories['religions']!.join(', ') 
          : 'Aucune',
      litteratures: categories['litteratures']!.isNotEmpty 
          ? categories['litteratures']!.join(', ') 
          : 'Aucun',
      psychologies: categories['psychologies']!.isNotEmpty 
          ? categories['psychologies']!.join(', ') 
          : 'Aucune',
      philosophies: categories['philosophies']!.isNotEmpty 
          ? categories['philosophies']!.join(', ') 
          : 'Aucun',
      philosophes: categories['philosophes']!.isNotEmpty 
          ? categories['philosophes']!.join(', ') 
          : 'Aucun',
      sourceChoisie: sourceConfig.name,
      penseeOuSituation: penseeOuSituation,
      historique7Jours: historique7Jours,
    );
    
    final systemPrompt = PromptSelector.getSystemPrompt(langReference);

    try {
      final response = await _callClaude(
        prompt,
        systemPrompt: systemPrompt,
        maxTokens: 500,
        useQualityModel: _requiresQualityModel(selectedSource),
      );
      
      if (response.startsWith('[ERREUR_API]')) {
        return '❌ ${response.replaceFirst('[ERREUR_API] ', '')}';
      }
      
      return response.isNotEmpty 
        ? response 
        : '❌ Impossible de générer une pensée positive.';
    } catch (e) {
      return '❌ Impossible de générer une pensée positive.';
    }
  }

  String _selectWeightedSource(List<String> sources) {
    if (sources.isEmpty) return _defaultSources.first;
    
    final weights = <String, double>{};
    for (final source in sources) {
      final usage = _sourceUsageHistory[source] ?? 0;
      weights[source] = 1.0 / (usage + 1);
    }
    
    final totalWeight = weights.values.reduce((a, b) => a + b);
    final random = Random().nextDouble() * totalWeight;
    
    double cumulative = 0;
    for (final entry in weights.entries) {
      cumulative += entry.value;
      if (random <= cumulative) {
        return entry.key;
      }
    }
    
    return sources.first;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GÉNÉRATION SYNTHÈSE VOCALE
  // ═══════════════════════════════════════════════════════════════════════════

  Future<String> generateSynthesis({
    required String systemPrompt,
    required String userPrompt,
    String? model,
    double temperature = 0.3,
    int maxTokens = 150,
  }) async {
    try {
      final response = await _callClaude(
        userPrompt,
        systemPrompt: systemPrompt,
        maxTokens: maxTokens,
        temperature: temperature,
        useQualityModel: false,
      );
      
      if (response.startsWith('[ERREUR_API]')) {
        throw Exception(response.replaceFirst('[ERREUR_API] ', ''));
      }
      
      if (response.isNotEmpty) {
        return response;
      } else {
        throw Exception('Réponse vide');
      }
    } catch (e) {
      rethrow;
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // GÉNÉRATION MULTIPLE
  // ═══════════════════════════════════════════════════════════════════════════

  Future<Map<String, String>> generateMultipleApproachResponses({
    required String reflectionText,
    required ReflectionType reflectionType,
    required EmotionalState emotionalState,
    required List<String> selectedApproaches,
    UserProfile? userProfile,
    String? declencheur,
    String? souhait,
    String? petitPas,
    int intensiteEmotionnelle = 5,
    String? historique30Jours,
  }) async {
    final responses = <String, String>{};
    
    for (final approach in selectedApproaches.take(5)) {
      try {
        final response = await generateApproachSpecificResponse(
          approach: approach,
          reflectionText: reflectionText,
          reflectionType: reflectionType,
          emotionalState: emotionalState,
          userProfile: userProfile,
          intensiteEmotionnelle: intensiteEmotionnelle,
          historique30Jours: historique30Jours,
        );
        responses[approach] = response;
      } catch (e) {
        responses[approach] = '❌ Erreur';
      }
    }
    
    return responses;
  }

  void resetSourceHistory() {
    _sourceUsageHistory.clear();
  }

  void clearUserData() {
    _userApproaches = [];
    _sourceUsageHistory.clear();
    print('AIService: Données utilisateur effacées');
  }
}
